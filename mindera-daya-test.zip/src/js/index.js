import store from "../js/store/index";
import { getData } from "../js/actions/index";
window.store = store;
window.getData=getData;

