import React, { Component } from 'react';
import Carousel from './components/Carsouel';
import './App.scss';

class App extends Component {
  render() {
    return (
      <div className="App">
       <Carousel/>
      </div>
    );
  }
}

export default App;
